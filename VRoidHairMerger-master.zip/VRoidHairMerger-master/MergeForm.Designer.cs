﻿using System.Drawing;
using System.Windows.Forms;

namespace VRoidHairMerger
{
    partial class MergeForm
    {
        private ComboBox sourcePreset1;
        private Label sourcePreset1Label;
        private Label sourcePreset2Label;
        private ComboBox sourcePreset2;
        private Button mergeButton;
        private Label pathLabel;
        private Label pathDirectory;
        private Button pathChangeButton;

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.sourcePreset1 = InitializePreset("sourcePreset1", ComboBoxStyle.DropDownList, true, new Point(15, 114), new System.Drawing.Size(197, 21), 0);
            this.sourcePreset2 = InitializePreset("sourcePreset2", ComboBoxStyle.DropDownList, true, new Point(266, 114), new Size(197, 21), 2);
            this.sourcePreset2.Anchor = (AnchorStyles)(AnchorStyles.Top | AnchorStyles.Right);
            this.sourcePreset1Label = InitializeLabel("sourcePreset1Label", "Source preset1", true, new Point(12, 98), new Size(82, 13), 1);
            this.sourcePreset2Label = InitializeLabel("sourcePreset2Label", "Source preset2", true, new Point(263, 98), new Size(82, 13), 3);
            this.sourcePreset2Label.Anchor = ((AnchorStyles)((AnchorStyles.Top | AnchorStyles.Right)));
            this.pathLabel = InitializeLabel("pathLabel", "Current hair preset path:", true, new Point(12, 9), new Size(120, 13), 5);
            this.pathDirectory = InitializeLabel("hairPath", "path", true, new Point(12, 28), new Size(28, 13), 6);
            this.mergeButton = InitializeButton("mergeButton", "Merge", new Point(358, 161), new Size(105, 23), true, 4);
            this.mergeButton.Anchor = (AnchorStyles)(AnchorStyles.Bottom | AnchorStyles.Right);
            this.mergeButton.Click += new System.EventHandler(this.MergeButton_Click);
            this.pathChangeButton = InitializeButton("pathChangeButton", "Change path", new Point(15, 47), new Size(106, 23), true, 7);
            this.pathChangeButton.Click += new System.EventHandler(this.PathChangeButton_Click);

            // MergeForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 197);
            this.Controls.AddRange(new Control[] { this.pathChangeButton, this.pathDirectory, this.pathLabel, this.mergeButton, this.sourcePreset2Label, this.sourcePreset2, this.sourcePreset1Label, this.sourcePreset1 });
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MergeForm";
            this.Text = "VRoidHairMerger";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        #region Initialize elements methods
        private Button InitializeButton(string name, string text, Point location, Size size, bool useBackColor, int tabIndex)
        {
            var initializedButton = new Button();
            initializedButton.Name = name;
            initializedButton.Text = text;
            initializedButton.Location = location;
            initializedButton.Size = size;
            initializedButton.UseVisualStyleBackColor = useBackColor;
            initializedButton.TabIndex = tabIndex;
            return initializedButton;
        }

        private Label InitializeLabel(string name, string text, bool autoSize, Point location, Size size, int tabIndex)
        {
            var initializedLabel = new Label();
            initializedLabel.Name = name;
            initializedLabel.Text = text;
            initializedLabel.AutoSize = autoSize;
            initializedLabel.Location = location;
            initializedLabel.Size = size;
            initializedLabel.TabIndex = tabIndex;
            return initializedLabel;
        }

        private ComboBox InitializePreset(string name, ComboBoxStyle cbxStyle, bool formattingEnabled, Point location, Size size, int tabIndex)
        {
            var initializedPreset = new ComboBox();
            initializedPreset.Name = name;
            initializedPreset.DropDownStyle = cbxStyle;
            initializedPreset.FormattingEnabled = formattingEnabled;
            initializedPreset.Location = location;
            initializedPreset.Size = size;
            initializedPreset.TabIndex = tabIndex;
            return initializedPreset;
        }
        #endregion
    }
}