﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VRoidHairMerger
{
    public partial class MergeForm : Form
    {
        private string Path { get; set; }

        public MergeForm()
        {
            Path = GetHairPath();
            InitializeComponent();
            LoadFrontend();
        }

        private string GetHairPath()
        {
            var defaultPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\AppData\LocalLow\pixiv\VRoidStudio\hair_presets";
            ValidatePath(defaultPath);
            return defaultPath;
        }
        private void ValidatePath(string path)
        {
            if (!Directory.Exists(path))
            {
                MessageBox.Show("Couldn't find the hair presets folder:\r\n" + path);
                return;
            }
        }

        private void LoadFrontend()
        {
            pathDirectory.Text = Path;

            var presetPaths = GetPresets(Path);
            var presetNames = GetNames(presetPaths);

            ClearComboBoxes();
            PopulateComboBoxes(presetNames);
        }

        private List<string> GetPresets(string path)
        {
            var filesInPathDirectory = Directory.GetDirectories(path).ToList();
            var presetPaths = filesInPathDirectory.Where(preset => new DirectoryInfo(preset).Name.Contains("preset")).ToList();
            return presetPaths;
        }

        private List<string> GetNames(List<string> presetPaths)
        {
            var presetNames = new List<string>();
            presetPaths.ForEach(presetPath => presetNames.Add(GetName(presetPath)));
            return presetNames;
        }

        private void ClearComboBoxes()
        {
            if (sourcePreset1.Items.Count > 0 || sourcePreset2.Items.Count > 0)
            {
                sourcePreset1.Items.Clear();
                sourcePreset2.Items.Clear();
            }
        }

        private void PopulateComboBoxes(List<string> presetNames)
        {
            foreach (var name in presetNames)
            {
                sourcePreset1.Items.Add(name);
                sourcePreset2.Items.Add(name);
            }
        }

        private string GetName(string presetPath)
        {
            var pathName = new DirectoryInfo(presetPath).Name;
            return pathName;
        }

        private void MergeButton_Click(object sender, EventArgs e)
        {
            if (HasSelectedPresets())
            {
                if (!HasSelectedSamePresetTwice())
                {
                    var presetPath = Path;
                    var source1Path = presetPath + @"\" + sourcePreset1.Text;
                    var source2Path = presetPath + @"\" + sourcePreset2.Text;

                    var destinationId = Convert.ToInt32(System.Text.RegularExpressions.Regex.Match(sourcePreset1.Items[sourcePreset1.Items.Count - 1].ToString(), @"\d+").Value) + 1;
                    var destinationPath = presetPath + @"\preset" + destinationId;

                    if (JsonFileExists(source1Path) && JsonFileExists(source2Path))
                    {
                        MessageBox.Show("If VRoid shows an error when starting the program after this, make sure to manually delete the destination preset folder:\r\n\r\n" + source2Path, "Reminder");
                        dynamic source1Data = ParseJson(source1Path);
                        dynamic source2Data = ParseJson(source2Path);
                        dynamic destinationData = source2Data;

                        CreateBaseFolder(destinationPath, source2Path);
                        destinationData = MergeFolders(destinationData, source1Data, destinationPath, source1Path);

                        // Save hair preset
                        SavePreset(destinationData, destinationPath);
                        MessageBox.Show("Merge complete. File saved as:\r\n" + destinationPath + @"\preset.json");
                    }
                    else
                    {
                        MessageBox.Show("Either of the preset-files does not exist.");
                    }
                }
                else
                {
                    MessageBox.Show("You must select 2 unique presets.");
                }
            }
            else
            {
                MessageBox.Show("You must select 2 preset sources.");
            }
        }

        private void SavePreset(dynamic data, string path)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(data);
            Encoding utf8WithoutBom = new UTF8Encoding(false);
            File.WriteAllText(path + @"\preset.json", json, utf8WithoutBom);
        }

        private dynamic MergeFolders(dynamic destinationData, dynamic source1Data, string destinationPath, string source1Path)
        {
            dynamic resultData = destinationData;
            var materialGuids = new List<string>();
            var hairGuids = new List<string>();

            // Loop through the hair array
            for (int i = 0; i < source1Data.Hairishes.Count; i++)
            {
                // Skip base hair since multiple instances will crash VRoid
                if (Convert.ToInt32(source1Data.Hairishes[i].Type ?? "0") != 3)
                {
                    // Copy hair data
                    resultData.Hairishes.Add(source1Data.Hairishes[i]);

                    var hairishId = i;
                    materialGuids = GetMaterialGuids(materialGuids, source1Data, hairishId);
                    hairGuids = GetHairGuids(hairGuids, source1Data, hairishId);


                    // Check materials also from children since some hair presets hide materials to child level
                    for (int j = 0; j < source1Data.Hairishes[i].Children.Count; j++)
                    {
                        if (!hairGuids.Contains((string)source1Data.Hairishes[i].Children[j].Id))
                            hairGuids.Add((string)source1Data.Hairishes[i].Children[j].Id);

                        string cmaterialID = source1Data.Hairishes[i].Children[j].Param._MaterialValueGUID;
                        if (cmaterialID.Length > 0)
                        {
                            if (!materialGuids.Contains(cmaterialID))
                                materialGuids.Add(cmaterialID);
                        }

                        string cmaterialInheritID = source1Data.Hairishes[i].Children[j].Param._MaterialInheritedValueGUID;
                        if (cmaterialInheritID.Length > 0)
                        {
                            if (!materialGuids.Contains(cmaterialInheritID))
                                materialGuids.Add(cmaterialInheritID);
                        }
                    }
                }
            }

            // Loop through materials
            for (int i = 0; i < source1Data._MaterialSet._Materials.Count; i++)
            {
                if (materialGuids.Contains((string)source1Data._MaterialSet._Materials[i]._Id))
                {
                    resultData._MaterialSet._Materials.Add(source1Data._MaterialSet._Materials[i]);
                    // Copy material texture as well
                    if (!File.Exists(destinationPath + "\\materials\\rendered_textures\\" + source1Data._MaterialSet._Materials[i]._MainTextureId + ".png"))
                        File.Copy(source1Path + "\\materials\\rendered_textures\\" + source1Data._MaterialSet._Materials[i]._MainTextureId + ".png",
                            destinationPath + "\\materials\\rendered_textures\\" + source1Data._MaterialSet._Materials[i]._MainTextureId + ".png");
                }
            }

            // Loop through bones
            for (int i = 0; i < source1Data._HairBoneStore.Groups.Count; i++)
            {
                // Make sure all hairs exist or skip the bone. Importing bones with non-existing hairs will crash VRoid
                bool okToAdd = true;
                for (int j = 0; j < source1Data._HairBoneStore.Groups[i].Hairs.Count; j++)
                {
                    if (!hairGuids.Contains((string)source1Data._HairBoneStore.Groups[i].Hairs[j]))
                    {
                        okToAdd = false;
                        break;
                    }
                }
                if (okToAdd)
                    destinationData._HairBoneStore.Groups.Add(source1Data._HairBoneStore.Groups[i]);
            }

            return destinationData;
        }

        private List<string> GetMaterialGuids(List<string> materialGuids, dynamic source1Data, int i)
        {
            string materialID = source1Data.Hairishes[i].Param._MaterialValueGUID;
            if (!materialGuids.Contains(materialID))
                materialGuids.Add(materialID);

            string materialInheritID = source1Data.Hairishes[i].Param._MaterialInheritedValueGUID;
            if (materialInheritID.Length > 0)
            {
                if (!materialGuids.Contains(materialInheritID))
                    materialGuids.Add(materialInheritID);
            }

            return materialGuids;
        }

        private List<string> GetHairGuids(List<string> guids, dynamic data, int i)
        {
            if (!guids.Contains((string)data.Hairishes[i].Id))
                guids.Add((string)data.Hairishes[i].Id);
            return guids;
        }

        private void CreateBaseFolder(string destinationPath, string sourcePath)
        {
            DirectoryCopy(sourcePath, destinationPath, true);
        }

        private static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            DirectoryInfo[] dirs = dir.GetDirectories();
            // If the destination directory doesn't exist, create it.
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = System.IO.Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, false);
            }

            // If copying subdirectories, copy them and their contents to new location.
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = System.IO.Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
            }
        }

        private static dynamic ParseJson(string source1Path)
        {
            return JObject.Parse(File.ReadAllText(source1Path + @"\preset.json", Encoding.UTF8));
        }

        private bool JsonFileExists(string path)
        {
            return File.Exists(path + @"\preset.json");
        }

        private bool HasSelectedSamePresetTwice()
        {
            var result = string.Compare(sourcePreset1.Text, sourcePreset2.Text);
            if (result == 0)
                MessageBox.Show("You selected the same preset twice.");
            return result == 0;
        }

        private bool HasSelectedPresets()
        {
            var validate1 = String.IsNullOrEmpty(sourcePreset1.Text);
            var validate2 = String.IsNullOrEmpty(sourcePreset2.Text);
            return !(validate1 && validate2);
        }

        private void PathChangeButton_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    Path = fbd.SelectedPath;
                    LoadFrontend();
                }
            }
        }
    }
}
